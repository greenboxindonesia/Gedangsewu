/* FlexSlider */
$(window).load(function(){
  $('.flexslider').flexslider({       
	animation: "fade",
	start: function(slider){
	  $('body').removeClass('loading');
	}
  });
});